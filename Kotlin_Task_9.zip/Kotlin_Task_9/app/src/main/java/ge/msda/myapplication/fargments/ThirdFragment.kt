package ge.msda.myapplication.fargments

import androidx.fragment.app.Fragment
import ge.msda.myapplication.R


class ThirdFragment : Fragment(R.layout.fragmnet_third) {
}