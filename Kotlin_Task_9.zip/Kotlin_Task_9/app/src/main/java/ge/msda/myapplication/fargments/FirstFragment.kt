package ge.msda.myapplication.fargments

import androidx.fragment.app.Fragment
import ge.msda.myapplication.R

/*
* Created by ნიკოლოზ კაციტაძე on 5/28/20
*/

class FirstFragment : Fragment(R.layout.fragmnet_first) {
}